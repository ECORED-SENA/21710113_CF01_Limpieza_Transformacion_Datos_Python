function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6A1SR4OD5gx":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

