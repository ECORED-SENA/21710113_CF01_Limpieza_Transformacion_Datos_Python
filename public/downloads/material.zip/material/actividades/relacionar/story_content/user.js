function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5w5otTnZrWy":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

